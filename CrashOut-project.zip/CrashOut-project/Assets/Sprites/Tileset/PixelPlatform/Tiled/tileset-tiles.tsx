<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="tileset-tiles" tilewidth="18" tileheight="18" tilecount="180" columns="20">
 <image source="../Tilemap/tilemap_packed.png" width="360" height="162"/>
</tileset>
